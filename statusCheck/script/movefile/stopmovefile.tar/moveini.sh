
declare -a service
service[0]='vid'
service[1]='visms'

#声明取话单主机的ip
declare -A host_ip
host_ip=( \
[vid]='127.0.0.1' \
[visms]='127.0.0.1' \
)

#声明取话单主机的账号
declare -A host_user
host_user=( \
[vid]='root' \
[visms]='root' \
)

#声明取话单主机的密码
declare -A host_passwd
host_passwd=( \
[vid]='6221363' \
[visms]='6221363' \
)

#声明取话单路径的数组
declare -A frompath
frompath=( \
[vid]='/root/statusCheck/test/vidsrouce/' \
[visms]='/root/statusCheck/test/vismssrouce/' \
)

#暂时输入文件在一个路径下
tpath=/root/statusCheck/test/filedir/

#输入文件的数组
declare -A topath
topath=( \
[vid]=$tpath \
[visms]=$tpath )

#声明临时文件的数组
declare -A tmp
tmp=( \
[vid]='vid.tmp' \
[visms]='visms.tmp' \
)



